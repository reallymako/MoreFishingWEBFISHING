Thanks for playing with MoreFishing!
MoreFishing is a new mod that adds 70+ new fish to WEBFISHING--to scratch your fishing itch!
Version: 2.0.0
Authors: reallymako


This mod was made with Hatchery 1.3.0
https://github.com/coolbot100s/Hatchery